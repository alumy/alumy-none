The Analog Devices ADSP-CM41x series support comes without any warranty and support from SEGGER Microcontroller GmbH. Support is provided via Analog Devices only.
For support, please contact: processor.tools.support@analog.com



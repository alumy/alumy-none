The ON Semiconductor devices support comes without any warranty and support from SEGGER Microcontroller GmbH. Support is provided via ON Semiconductor only.
For support, please contact: dsp.support@onsemi.com
On the ON Semiconductor website, other documents, such as the datasheet, etc. can be found 


